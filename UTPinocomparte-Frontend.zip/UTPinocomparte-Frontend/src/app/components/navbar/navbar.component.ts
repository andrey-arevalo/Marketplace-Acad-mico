import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {
  menuAbierto = false;
  modoOscuro = false;

  alternarMenu(): void {
    this.menuAbierto = !this.menuAbierto;
  }

  alternarTema(): void {
    this.modoOscuro = !this.modoOscuro;
    document.documentElement.classList.toggle('dark', this.modoOscuro);
  }
}
